package com.example.catmovies.test;

import org.junit.Test;

import static org.junit.Assert.*;

public class RunnerTest {

    @Test
    public void testFilmAndReview() {
    }

    @Test
    public void testTheatre() {
    }

    @Test
    public void main() {
    }
}