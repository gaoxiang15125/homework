//
// 此文件是由 JavaTM Architecture for XML Binding (JAXB) 引用实现 v2.2.7 生成的
// 请访问 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 在重新编译源模式时, 对此文件的所有修改都将丢失。
// 生成时间: 2018.06.06 时间 09:50:00 PM CST 
//


package com.example.integration.po.catpo;

import javax.xml.bind.annotation.XmlRegistry;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.catmovies.webservices.service package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {


    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.catmovies.webservices.service
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link CatTheatrePo }
     * 
     */
    public CatTheatrePo createCatTheatrePo() {
        return new CatTheatrePo();
    }

    /**
     * Create an instance of {@link CatTheatrePo.Tickets }
     * 
     */
    public CatTheatrePo.Tickets createCatTheatrePoTickets() {
        return new CatTheatrePo.Tickets();
    }

    /**
     * Create an instance of {@link GetAllTheatresResponse }
     * 
     */
    public GetAllTheatresResponse createGetAllTheatresResponse() {
        return new GetAllTheatresResponse();
    }

    /**
     * Create an instance of {@link GetAllMoviesResponse }
     * 
     */
    public GetAllMoviesResponse createGetAllMoviesResponse() {
        return new GetAllMoviesResponse();
    }

    /**
     * Create an instance of {@link GetAllMoviesRequest }
     * 
     */
    public GetAllMoviesRequest createGetAllMoviesRequest() {
        return new GetAllMoviesRequest();
    }

    /**
     * Create an instance of {@link CatTicketPo }
     * 
     */
    public CatTicketPo createCatTicketPo() {
        return new CatTicketPo();
    }

    /**
     * Create an instance of {@link GetAllTheatresRequest }
     * 
     */
    public GetAllTheatresRequest createGetAllTheatresRequest() {
        return new GetAllTheatresRequest();
    }

    /**
     * Create an instance of {@link CatEyePo }
     * 
     */
    public CatEyePo createCatEyePo() {
        return new CatEyePo();
    }

    /**
     * Create an instance of {@link CatReviewPo }
     * 
     */
    public CatReviewPo createCatReviewPo() {
        return new CatReviewPo();
    }

    /**
     * Create an instance of {@link CatTheatrePo.Tickets.Entry }
     * 
     */
    public CatTheatrePo.Tickets.Entry createCatTheatrePoTicketsEntry() {
        return new CatTheatrePo.Tickets.Entry();
    }

}
