package spair;

/**
 * @program: IntegrateHomework
 * @description: 猫眼网站信息爬取类
 * @author: gaoxiang
 * @create: 2018-06-04 15:16
 **/
public class CatEyeSpair {

}
