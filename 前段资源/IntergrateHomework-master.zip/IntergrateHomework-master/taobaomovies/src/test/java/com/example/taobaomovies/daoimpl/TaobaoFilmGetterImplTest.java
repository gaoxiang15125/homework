package com.example.taobaomovies.daoimpl;

import org.junit.Test;

import static org.junit.Assert.*;

public class TaobaoFilmGetterImplTest {

    @Test
    public void insert() {
    }

    @Test
    public void getAllFilm() {
    }
}